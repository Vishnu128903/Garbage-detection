# garbage and pothole > 2024-12-24 6:28pm
https://universe.roboflow.com/ab-q5wkj/garbage-and-pothole

Provided by a Roboflow user
License: CC BY 4.0

